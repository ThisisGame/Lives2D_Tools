//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by nodetrak.rc
//
#define IDS_DB_NODETRAK                 1
#define IDS_DB_IMAGE_FILTER             2
#define IDS_DB_NODE_TRACKER             3
#define IDS_LIBDESCRIPTION              4
#define IDD_NODETRAK_ABOUT              101
#define IDD_NODETRAK_CONTROL            102
#define IDC_IN                          1001
#define IDC_OUT                         1002
#define IDC_NODENAME                    1002
#define IDC_PICKNODE                    1003
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
