//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by glow.rc
//
#define IDS_DB_GLOW                     1
#define IDS_DB_IMAGE_FILTER             2
#define IDS_LIBDESCRIPTION              3
#define IDS_DB_GLOW_COLOR               4
#define IDS_GG_DESCRIPTION              5
#define IDD_GLOW_ABOUT                  101
#define IDD_GLOW_CONTROL                102
#define IDC_MTLID_BUTT                  1001
#define IDC_NODEID_BUTT                 1002
#define IDC_MTLCOLOR_BUTT               1003
#define IDC_USERCOLOR_BUTT              1004
#define IDC_MTLID_EDIT                  1026
#define IDC_NODEID_EDIT                 1027
#define IDC_SIZE_EDIT                   1028
#define IDC_COLOR_SWATCH                1029
#define IDC_MTLID_SPIN                  1046
#define IDC_NODEID_SPIN                 1047
#define IDC_SIZE_SPIN                   1048
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1005
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
