//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by custctrl.rc
//
#define IDD_CUSTCTRL                    102
#define IDB_IMAGE                       103
#define IDB_FLYOFFIMAGE                 105
#define IDB_FLYOFFMASK                  106
#define IDB_IMAGEMASK                   107
#define IDD_MAXDLG                      116
#define IDS_LIBDESCRIPTION              117
#define IDB_TB                          159
#define IDB_TBMASK                      160
#define IDC_SPIN_EDIT                   1000
#define IDC_SPIN_SPINNER                1001
#define IDC_SPIN_TCBSPIN                1002
#define IDC_SPIN_TCBEDIT                1003
#define IDC_IMAGE                       1006
#define IDC_COLORSWATCH                 1007
#define IDC_STATUS                      1008
#define IDC_FLYOFFINDEX                 1009
#define IDC_SPINEDIT_VALUE              1010
#define IDC_TBCHECK                     1011
#define IDC_SPIN_STATUS                 1012
#define IDC_BUTTON_TEXT                 1013
#define IDC_IMAGE2D                     1014
#define IDC_TCB_GRAPH                   1015
#define IDC_DADWINDOW                   1017
#define IDC_FROM_TYPE                   1018
#define IDC_FROM_XY                     1019
#define IDC_IS_NEW                      1020
#define IDC_TO_TYPE                     1021
#define IDC_TO_XY                       1022
#define IDC_MAYBE_DROP                  1023
#define IDC_COLOR_DLG                   1024
#define IDC_TO_WHO                      1025
#define IDC_TVP_DLG                     1026
#define IDC_EXCL_DLG                    1027
#define IDC_MTL_DLG                     1028
#define IDC_EDIT                        1029
#define IDC_HBN_DLG                     1030
#define IDC_NCP_DLG                     1031
#define IDC_ARC_DLG                     1032
#define IDC_DLG1                        1033
#define IDC_INFO1                       1033
#define IDC_DLG2                        1034
#define IDC_DADBUTTON                   1034
#define IDC_INFO2                       1034
#define IDC_DLG3                        1035
#define IDC_INFO3                       1035
#define IDC_SLIDER                      1035
#define IDC_CHOOSE_DIR                  1036
#define IDC_SLIDER_EDIT                 1036
#define IDC_SLIDER1                     1037
#define IDC_SLIDER_EDIT1                1038
#define IDC_SLIDER2                     1039
#define IDC_SLIDER_EDIT2                1040
#define IDC_SLIDE_VALUE                 1042
#define IDC_SLIDE1_VALUE                1043
#define IDC_BUTTON1                     1059
#define IDC_BUTTON_CHECK                1059
#define IDC_BUTTON0                     1060
#define IDC_BUTTON_PUSH                 1060
#define IDC_TOOLBAR                     1064
#define IDC_FLYOFF                      1065

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        118
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1035
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
