//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by PerFaceData.rc
//
#define IDS_LIBDESCRIPTION              1
#define IDS_CATEGORY                    2
#define IDS_RANDOM_CLASS_NAME           3
#define IDS_PARAMS                      4
#define IDS_SEED                        5
#define IDS_FACE_SELECTED               6
#define IDS_FACES_SELECTED              7
#define IDS_NO_FACE_SELECTED            8
#define IDS_EDIT_CLASS_NAME             9
#define IDS_FACE                        10
#define IDS_EDIT_FACE_DATA              11
#define IDS_OBJECT_SELECTED             12
#define IDS_RESET_SELECTED              13
#define IDS_RESET_ALL                   14
#define IDS_COLOR_CLASS_NAME            15
#define IDS_COLOR_CHANNEL               16
#define IDS_RED_MULT                    17
#define IDS_GREEN_MULT                  18
#define IDS_BLUE_MULT                   19
#define IDS_COLLAPSABLE                 20
#define IDS_RANGE                       21
#define IDS_FACE_DATA_EXPORT            22
#define IDD_RANDOM_DATA                 101
#define IDD_DATA_TO_COLOR               102
#define IDD_FACEDATA_EDIT               103
#define IDC_FACE_SELECTED               1002
#define IDC_VALUE_SPIN                  1003
#define IDC_VALUE                       1004
#define IDC_VIEW_OPTION                 1005
#define IDC_ILLUM                       1007
#define IDC_RED_SPIN                    1009
#define IDC_RED                         1010
#define IDC_GREEN                       1011
#define IDC_GREEN_SPIN                  1012
#define IDC_BLUE                        1013
#define IDC_BLUE_SPIN                   1014
#define IDC_DISPLAY_NOW                 1015
#define IDC_COLLAPSABLE                 1016
#define IDC_COLOR                       1456
#define IDC_RANGE                       1490
#define IDC_SEED                        1491
#define IDC_RANGE_SPIN                  1496
#define IDC_SEED_SPIN                   1497
#define IDC_RESET_SELECTION             2061

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1017
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
