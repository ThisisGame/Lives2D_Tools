//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by CVDExport.rc
//
#define IDS_CLASSNAME                   1
#define IDS_PARAMETERS                  2
#define IDS_SEARCH                      3
#define IDS_LIBDESC                     4
#define IDS_EXT_01                      5
#define IDS_SHORTDESC                   6
#define IDS_LONGDESC                    7
#define IDS_AUTHOR                      8
#define IDS_COPYRIGHT                   9
#define IDD_CVDEXP                      101
#define IDD_ABOUT                       102
#define IDC_OK                          1001
#define IDC_CANCEL                      1002
#define IDC_SEARCH1                     1003
#define IDC_SEARCH2                     1004

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
