//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by CustomVData.rc
//
#define IDS_CLASSNAME                   1
#define IDC_CLASSNAME                   1
#define IDS_PARAMETERS                  2
#define IDS_LIBDESC                     4
#define IDS_SIMPLE                      5
#define IDS_COLORV                      6
#define IDS_VDATA                       7
#define IDS_CVD                         8
#define IDD_SKELETON_PMOD               101
#define IDD_CUSTOMDATA                  101
#define IDC_SIMPLE_EDIT                 1004
#define IDC_CVD_EDIT                    1004
#define IDC_SIMPLE_SPIN                 1006
#define IDC_CVD_SPIN                    1006

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
