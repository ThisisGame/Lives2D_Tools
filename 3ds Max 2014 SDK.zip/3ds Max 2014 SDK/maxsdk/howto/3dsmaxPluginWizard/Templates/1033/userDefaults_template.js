window.external.AddSymbol("SDKPATH", "[!output SDKPATH_PRINTABLE]");
window.external.AddSymbol("PLGPATH", "[!output PLGPATH_PRINTABLE]");
window.external.AddSymbol("EXEPATH", "[!output EXEPATH_PRINTABLE]");
window.external.AddSymbol("PLGPATHX64", "[!output PLGPATHX64_PRINTABLE]");
window.external.AddSymbol("EXEPATHX64", "[!output EXEPATHX64_PRINTABLE]");