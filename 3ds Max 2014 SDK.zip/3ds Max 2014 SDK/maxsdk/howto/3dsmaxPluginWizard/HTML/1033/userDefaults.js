window.external.AddSymbol("SDKPATH", "<3dsMax_SDK_Root_Path>");
window.external.AddSymbol("PLGPATHX64", "<3dsMax_x64_Root_Path>\\plugins");
window.external.AddSymbol("EXEPATHX64", "<3dsMax_x64_Root_Path>");