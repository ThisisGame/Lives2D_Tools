//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SineWave.rc
//
#define IDS_LIBDESCRIPTION              1
#define IDS_CATEGORY                    2
#define IDS_PSCLASS_NAME                3
#define IDS_PSPARAMS                    4
#define IDS_SPIN                        5
#define IDS_AMOUNT                      5
#define IDS_COORDS                      7
#define IDS_PSCATEGORY                  8
#define IDS_VSCATEGORY                  9
#define IDS_VSCLASS_NAME                10
#define IDS_VSPARAMS                    11
#define IDS_BPSCLASS_NAME               12
#define IDS_CUBEMAPFILENAME             13
#define IDS_VSFILENAME                  14
#define IDS_CM_FILE_TYPES               15
#define IDS_VS_FILE_TYPES               16
#define IDS_VS_FAIL                     17
#define IDS_HS                          18
#define IDS_VSLOAD_FAIL                 19
#define IDS_NORMAL                      20
#define IDS_HEIGHT                      21
#define IDS_WIREFRAME                   22
#define IDD_PSPANEL                     101
#define IDD_VSPANEL                     102
#define IDD_BPSPANEL                    103
#define IDC_CLOSEBUTTON                 1000
#define IDC_DOSTUFF                     1000
#define IDC_CUBEMAP                     1005
#define IDC_VSFILE                      1006
#define IDC_NORMAL                      1007
#define IDC_WIREFRAME                   1008
#define IDC_COLOR                       1456
#define IDC_EDIT                        1490
#define IDC_HEIGHTEDIT                  1491
#define IDC_SPIN                        1496
#define IDC_HEIGHTSPIN                  1497

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1008
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
