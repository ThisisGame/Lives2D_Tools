This is a sample project which produces a modifier to monitor PolyObjects,
and ensure that they maintain consistency.
