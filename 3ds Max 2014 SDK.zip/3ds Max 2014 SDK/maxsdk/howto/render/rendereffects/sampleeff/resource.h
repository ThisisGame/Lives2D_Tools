//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by sampleEff.rc
//
#define IDD_SAMPLE_EFFECT               111
#define IDC_BACKGROUND                  1701
#define IDC_SAMP_COLOR                  1702
#define IDC_SLOW                        1703
#define IDC_STRENGTH                    1704
#define IDC_STRENGTH_SPIN               1705
#define IDC_IGN_BACKGROUND              1706
#define IDS_LIBDESCRIPTION              30501
#define IDS_PARAMS                      30502
#define IDS_NAME                        30503
#define IDS_CLASS_NAME                  30504
#define IDS_CDESC_CLASS_NAME            30505
#define IDS_COLOR                       30506
#define IDS_STRENGTH                    30507
#define IDS_SLOW                        30508
#define IDS_IGN_BACK                    30509
#define IDS_GIZMO                       30510
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        112
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1706
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
