//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by cjrender.rc
//
#define IDS_YES                         1
#define IDS_NO                          2
#define IDS_LIB_DESCRIPTION             3
#define IDS_TAB_ROLLOUT                 4
#define IDD_CCJRENDERDLG                101
#define IDD_CCJRENDERDLG_PROG           102
#define IDC_AA_NONE                     1001
#define IDC_AA_MEDIUM                   1002
#define IDC_AA_HIGH                     1003
#define IDC_REFLENV                     1004
#define IDC_ANTIALIAS                   1005
#define IDC_PROG_DEPTH                  1006
#define IDC_PROG_ANTIALIAS              1007
#define IDC_PROG_REFLENV                1008
#define IDC_DEPTH                       1109
#define IDC_DEPTH_SPIN                  1110

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1011
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
