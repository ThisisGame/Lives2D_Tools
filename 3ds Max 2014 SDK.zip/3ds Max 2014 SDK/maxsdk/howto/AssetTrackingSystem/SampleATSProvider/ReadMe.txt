Sample ATS Provider
===================

SampleATSProvider is a template project for creating Asset Tracking System (ATS) Providers. This
project does not provide any asset tracking. It simply shows how to implement an ATS
plugin and interact with the ATS objects.

SampleATSProvider implements the required exports and IATSProvider interface.

ATS Provider plugins must be placed in the <3dsMax>\stdplugs\AssetTracking folder to be loaded.
