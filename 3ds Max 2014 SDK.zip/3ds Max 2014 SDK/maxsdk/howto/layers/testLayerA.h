/**********************************************************************
 *<
	FILE: testLayerA.h

	DESCRIPTION:	Includes for Plugins

	CREATED BY:

	HISTORY:

 *>	Copyright (c) 2003, All Rights Reserved.
 **********************************************************************/

#ifndef __LayerBoss__H
#define __LayerBoss__H

#include "Max.h"
#include "resource.h"
#include "istdplug.h"
#include "iparamb2.h"
#include "iparamm2.h"
//SIMPLE TYPE

#include <guplib.h>


extern TCHAR *GetString(int id);

extern HINSTANCE hInstance;

#endif
