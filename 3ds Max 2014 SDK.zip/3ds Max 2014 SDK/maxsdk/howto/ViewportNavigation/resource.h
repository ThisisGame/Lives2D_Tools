//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by ViewportNavigation.rc
//
#define IDS_LIBDESCRIPTION              1
#define IDS_CATEGORY                    2
#define IDS_CLASS_NAME                  3
#define IDS_PARAMS                      4
#define IDS_PAN_MODE                    5
#define IDS_ROTATE_MODE                 6
#define IDS_ZOOM_MODE                   7
#define IDD_PANEL                       101
#define IDC_PAN_CURSOR                  123
#define IDC_ROTATE_CURSOR               124
#define IDC_ZOOM_CURSOR                 125
#define IDC_PAN                         1001
#define IDC_ZOOM                        1003
#define IDC_ROTATE                      1004

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1005
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
