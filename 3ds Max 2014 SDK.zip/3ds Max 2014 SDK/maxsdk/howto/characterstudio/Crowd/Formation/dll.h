/**********************************************************************
 *<
	Crowd / Unreal Pictures

 *>	Copyright (c) 1999, All Rights Reserved.
 **********************************************************************/
 
/**********************************************************************
	FILE: dll.h
 **********************************************************************/

#ifndef __DLL__H
#define __DLL__H

#include "max.h" 

extern ClassDesc* GetFormationBhvrDesc();
extern HINSTANCE hInstance;
extern TCHAR *GetString(int id);

#endif

