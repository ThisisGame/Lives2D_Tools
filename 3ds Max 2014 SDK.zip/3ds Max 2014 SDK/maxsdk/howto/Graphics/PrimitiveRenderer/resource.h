//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by PrimitiveRenderer.rc
//
#define IDS_LIBDESCRIPTION              1
#define IDS_CATEGORY                    2
#define IDS_CLASS_NAME                  3
#define IDS_PARAMS                      4
#define IDS_SPIN                        5
#define IDD_PANEL                       101
#define IDC_CLOSEBUTTON                 1000
#define IDC_DOSTUFF                     1000
#define IDC_COLOR                       1456
#define IDC_EDIT                        1490
#define IDC_DRAW_PRIMITIVE              1490
#define IDC_LEFT_EDIT                   1491
#define IDC_RIGHT_EDIT                  1492
#define IDC_SPIN                        1496
#define IDC_SIZE_SPIN                   1496
#define IDC_LEFT_SPIN                   1497
#define IDC_SPIN3                       1498
#define IDC_RIGHT_SPIN                  1498
#define IDC_SIZE_EDIT                   1499


// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
