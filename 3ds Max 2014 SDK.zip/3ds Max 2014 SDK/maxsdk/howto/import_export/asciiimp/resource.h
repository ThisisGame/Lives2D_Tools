//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by asciiimp.rc
//
#define IDD_PANEL                       101
#define IDD_ABOUTBOX                    102
#define IDD_ASCIIIMPORT_DLG             103
#define IDS_LIBDESCRIPTION              105
#define IDC_RESETSCENE                  1002
#define IDC_INVERSE_INHERIT             1018
#define IDC_BUTTON1                     1019

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        106
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1020
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
