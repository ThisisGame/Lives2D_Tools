//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by objimp.rc
//
#define IDS_TH_SCENEIMPORT              40217
#define IDS_TH_COPYRIGHT_YOST_GROUP     40223
#define IDS_TH_WAVEFRONT                40246
#define IDS_LIBDESCRIPTION              40247
#define IDS_TH_WAVEFRONTOBJFILE         40248
#define IDS_TH_DON_AND_TOM              40249
#define IDS_TH_WAVE_OBJ_NAME            40252

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
