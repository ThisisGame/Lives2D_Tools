//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by tmattest.rc
//
#define IDD_MAIN                        103
#define IDD_ROT                         106
#define IDD_TRANS                       107
#define IDD_SCALE                       110
#define IDD_VIEW                        111
#define IDD_VIEW_TM                     113
#define IDS_LIBDESCRIPTION              113
#define IDD_VIEW_FLOAT                  114
#define IDC_VIEW_CURRENT                1000
#define IDC_CHECK_USE_Z                 1001
#define IDC_OBJECTTM                    1001
#define IDC_CHECK_USE_Y                 1002
#define IDC_OBJTMBEFORE                 1002
#define IDC_CHECK_USE_X                 1003
#define IDC_OBJTMAFTER                  1003
#define IDC_CHECK_USE_TR                1004
#define IDC_PARENTTM                    1004
#define IDC_CHECK_USE_SC                1005
#define IDC_TARGETTM                    1005
#define IDC_NODE_TM                     1006
#define IDC_SEDIT_ROT                   1006
#define IDC_OBJECTSTATE                 1006
#define IDC_RESET                       1007
#define IDC_SPIN_ROT                    1007
#define IDC_TM                          1007
#define IDC_CHECK_AUTO                  1008
#define IDC_OBJ_OFFSET                  1008
#define IDC_BUTTON_VIEW                 1010
#define IDC_SEDIT_XTR                   1011
#define IDC_SPIN_XTR                    1012
#define IDC_SPIN_YTR                    1013
#define IDC_SEDIT_YTR                   1014
#define IDC_SPIN_ZTR                    1015
#define IDC_SEDIT_ZTR                   1016
#define IDC_BUTTON_EDITTR               1017
#define IDC_M00                         1018
#define IDC_SEDIT_XSC                   1019
#define IDC_M10                         1019
#define IDC_SPIN_XSC                    1020
#define IDC_M20                         1020
#define IDC_SEDIT_YSC                   1021
#define IDC_M30                         1021
#define IDC_SPIN_YSC                    1022
#define IDC_M01                         1022
#define IDC_SEDIT_ZSC                   1023
#define IDC_M11                         1023
#define IDC_SPIN_ZSC                    1024
#define IDC_M21                         1024
#define IDC_M31                         1025
#define IDC_M02                         1026
#define IDC_BUTTON_EDITSC               1026
#define IDC_M12                         1027
#define IDC_M22                         1028
#define IDC_M32                         1029
#define IDC_C                           1029
#define IDC_S                           1030
#define IDC_VIEW_TITLE                  1034
#define IDC_RADIOX                      1035
#define IDC_VIEW_TITLE2                 1035
#define IDC_RADIOY                      1036
#define IDC_VIEW_TITLE3                 1036
#define IDC_RADIOZ                      1037
#define IDC_VIEW_TITLE4                 1037
#define IDC_MATLINE1                    1038
#define IDC_MATLINE2                    1039
#define IDC_MATLINE3                    1040
#define IDC_BORDER                      1041
#define IDC_MATLINE4                    1042
#define IDC_NODETM                      1046

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        114
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1047
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
