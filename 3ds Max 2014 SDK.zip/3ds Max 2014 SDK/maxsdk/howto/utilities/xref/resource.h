//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by xrefutil.rc
//
#define IDS_LIBDESCRIPTION              1
#define IDS_CATEGORY                    2
#define IDS_CLASS_NAME                  3
#define IDS_PARAMS                      4
#define IDS_SPIN                        5
#define IDS_ERR1                        6
#define IDS_ERRTITLE                    7
#define IDS_ERR2                        8
#define IDS_ERR3                        9
#define IDD_PANEL                       101
#define IDD_PICKOBJ                     102
#define IDD_DLGEXPORT                   103
#define IDC_CLOSEBUTTON                 1000
#define IDC_DOSTUFF                     1000
#define IDC_CMD_XO_CNVSEL               1001
#define IDC_CLOSE                       1002
#define IDC_CMD_XO_ADD                  1003
#define IDC_LIST_NODES                  1003
#define IDC_CMD_XS_ADD                  1004
#define IDC_CMD_XS_CNV                  1005
#define IDC_CMD_XS_RFS                  1006
#define IDC_CHK_PROXY                   1007
#define IDC_CMD_XS_MRG                  1007
#define IDC_CHK_NOANIM                  1008
#define IDC_CMD_XO_EXP                  1008
#define IDC_CMD_IXOMGR_ADD              1009
#define IDC_CMD_IXOMGR_REFRESH          1010
#define IDC_EDIT_EXPRES                 1011
#define IDC_CMD_IXOMGR_GETALL           1012
#define IDC_COLOR                       1456
#define IDC_EDIT                        1490
#define IDC_SPIN                        1496

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1013
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
