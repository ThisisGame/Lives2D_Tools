//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by MeshSplit.rc
//
#define IDS_AVCU_CNAME                  1
#define IDS_AVCU_PANELTITLE             2
#define IDS_AVCM_CNAME                  3
#define IDS_AVCM_ONAME                  4
#define IDS_AVCM_PANELTITLE             5
#define IDS_AVCU_PROGRESS               6
#define IDS_LIBDESCRIPTION              7
#define IDS_HOLDMSG_APPLYVTXCOLOR       8
#define IDS_PROGRESSMSG_RENDERING       9
#define IDS_MAPNAME_NONE                10
#define IDS_HOLDMSG_ADDMODIFIER         11
#define IDS_HOLDMSG_DELETEMODIFIER      12
#define IDS_MAPNAME_FORMATSTR           13
#define IDS_SPLIT_MESHES                13
#define IDS_SPLIT_MESHES_DIALOG_TITLE   14
#define IDD_SPLIT_MESHES                104
#define IDC_CLOSEBUTTON                 1000
#define IDC_VCUTIL_APPLY                1001
#define IDC_VCUTIL_AMBIENT              1002
#define IDC_VCUTIL_DIFFUSE              1003
#define IDC_VCUTIL_SCENELIGHTS          1004
#define IDC_VCUTIL_SHADED               1004
#define IDC_VCUTIL_UPDATEALL            1005
#define IDC_MIX                         1006
#define IDC_CASTSHADOWS                 1007
#define IDC_USEMAPS                     1008
#define IDC_VCUTIL_LIGHTING             1009
#define IDC_USERADIOSITY                1010
#define IDC_RADIOSITYONLY               1011
#define IDC_VCUTIL_EDITCOLORS           1012
#define IDC_VCUTIL_COLORBYFACE          1013
#define IDC_VCUTIL_COLORBYVERT          1014
#define IDC_VCUTIL_CHAN_COLOR           1015
#define IDC_VCUTIL_CHAN_ILLUM           1016
#define IDC_VCUTIL_CHAN_ALPHA           1017
#define IDC_VCUTIL_CHAN_MAP             1018
#define IDC_VCUTIL_CHAN_MAP_EDIT        1019
#define IDC_VCUTIL_CHAN_MAP_SPIN        1020
#define IDC_VCUTIL_CHAN_NAME            1021
#define IDC_PROGRESSDLG_STATUS          1022
#define IDC_SPLIT_MESHES_APPLY          1022
#define IDC_PROGRESSDLG_PROGRESS        1023

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1023
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
