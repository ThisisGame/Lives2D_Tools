//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Notify.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_NOTIFY_DIALOG               102
#define IDS_COMPLETION_TITLE            103
#define IDS_FAILURE_TITLE               104
#define IDS_APPTITLE_VIZ                105
#define IDS_ABOUTBOX_VIZ		            106
#define IDD_ABOUTBOX_VIZ                107
#define IDS_ABOUTBOX_LN1_VIZ						108
#define IDS_PROGRESS_TITLE              112
#define IDS_APPTITLE                    113
#define IDR_MAINFRAME_VIZ               120
#define IDR_MAINFRAME                   128
#define IDD_SOUNDS                      129
#define	IDC_STATIC_LN1			130
#define IDC_FAILURE_ED                  1000
#define IDC_PROGRESS_ED                 1001
#define IDC_COMPLETION_ED               1002
#define IDC_BROWSE_FAILURE              1004
#define IDC_BROWSE_PROGRESS             1005
#define IDC_BROWSE_COMPLETION           1006
#define IDC_PLAY_FAILURE                1007
#define IDC_PLAY_PROGRESS               1008
#define IDC_PLAY_COMPLETION             1009
#define IDC_LOGO                        1258

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1009
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
