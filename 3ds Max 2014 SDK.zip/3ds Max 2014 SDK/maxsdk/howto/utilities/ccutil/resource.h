//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by CCUtil.rc
//
#define IDS_LIBDESCRIPTION              1
#define IDS_CATEGORY                    2
#define IDS_CLASS_NAME                  3
#define IDS_PARAMS                      4
#define IDD_PANEL                       101
#define IDB_MASK_DISPLAYRGB             125
#define IDB_DISPLAYRGB                  127
#define IDC_CLOSEBUTTON                 1000
#define IDC_DOSTUFF                     1000
#define IDC_CC                          1001
#define IDC_MINUS                       1002
#define IDC_PLUS                        1003
#define IDC_SETCOLOR                    1004
#define IDC_SC_R                        1005
#define IDC_SC_G                        1006
#define IDC_SC_B                        1007
#define IDC_SC_CURVENUMBER              1008
#define IDC_SETDCOLOR                   1009
#define IDC_DISPEDIT                    1010
#define IDC_SETDISP                     1011
#define IDC_CMD_EDIT                    1012
#define IDC_GETZOOM                     1013
#define IDC_GETSCROLL                   1014
#define IDC_CMD_SET                     1015
#define IDC_SETANIMATED                 1016
#define IDC_GETVAL                      1017
#define IDC_GETDISABLED                 1018
#define IDC_DRAWBG                      1024
#define IDC_DRAWGRID                    1025
#define IDC_DRAWUTOOLBAR                1026
#define IDC_DRAWLTOOLBAR                1027
#define IDC_DRAWSCROLLBARS              1028
#define IDC_DRAWRULER                   1029
#define IDC_ASPOPUP                     1030
#define IDC_PT_IN_X                     1031
#define IDC_PT_IN_Y                     1032
#define IDC_PT_POS_X                    1033
#define IDC_PT_INDEX                    1034
#define IDC_PT_SET                      1035
#define IDC_AUTOSCROLL                  1036
#define IDC_PT_GET                      1037
#define IDC_PT_INSERT                   1038
#define IDC_PT_NUM                      1039
#define IDC_PT_POS_Y                    1040
#define IDC_PT_OUT_X                    1041
#define IDC_PT_OUT_Y                    1042
#define IDC_CURVE                       1043
#define IDC_CORNER                      1044
#define IDC_BEZIER                      1045
#define IDC_CONSTRAIN_Y                 1046
#define IDC_LOCKED_X                    1047
#define IDC_LOCKED_Y                    1048
#define IDC_PT_DELETE                   1049
#define IDC_SHOWRESET                   1050
#define IDC_RCMENU_MOVE_XY              1051
#define IDC_RCMENU_MOVE_X               1052
#define IDC_RCMENU_MOVE_Y               1053
#define IDC_RCMENU_SCALE                1054
#define IDC_RCMENU_INSERT_CORNER        1055
#define IDC_RCMENU_INSERT_BEZIER        1056
#define IDC_RCMENU_DELETE               1057
#define IDC_POS_X                       1058
#define IDC_POS_Y                       1059
#define IDC_GET_PLACEMENT               1060
#define IDC_SET_PLACEMENT               1061
#define IDC_HIDE_DISABLED_CURVES        1062
#define IDC_WIDTH                       1063
#define IDC_STYLE                       1064
#define IDC_SIZE_X                      1068
#define IDC_SIZE_Y                      1069
#define IDC_COLOR                       1456
#define IDC_EDIT                        1490
#define IDC_SPIN                        1496
#define IDC_XMIN                        3023
#define IDC_XZOOM                       3024
#define IDC_XSCROLL                     3025
#define IDC_XMAX                        3026
#define IDC_YZOOM                       3027
#define IDC_XMIN_SPIN                   3028
#define IDC_XMAX_SPIN                   3029
#define IDC_XZOOM_SPIN                  3030
#define IDC_YZOOM_SPIN                  3031
#define IDC_XSCROLL_SPIN                3032
#define IDC_YSCROLL                     3033
#define IDC_YSCROLL_SPIN                3034

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1064
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
