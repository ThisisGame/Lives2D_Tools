//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by DynPBlock.rc
//
#define IDS_LIBDESCRIPTION              1
#define IDS_CATEGORY                    2
#define IDS_CLASS_NAME                  3
#define IDS_PARAMS                      4
#define IDS_SPIN                        5
#define IDS_CHECK                       6
#define IDS_DYNPARAMS                   7
#define IDS_SIMPLEPARAMS                7
#define IDS_STRING                      8
#define IDS_DYNPARAMS2                  9
#define IDS_MATCACLASSNAME              10
#define IDS_CACOLOR                     11
#define IDS_COLOR                       11
#define IDS_CUSTOM_ATTRIBUTES           12
#define IDS_MPCA_CLASSNAME              13
#define IDS_SIMPLE_CLASSNAME            13
#define IDS_SUBMAP                      14
#define IDS_SIMPLECA                    15
#define IDS_SWATCHCA                    16
#define IDS_SWATCH_CLASSNAME            17
#define IDS_SWATCHPARAMS                18
#define IDS_SWATCHCOLOR                 19
#define IDS_NODECA                      20
#define IDS_NODE_CLASSNAME              21
#define IDS_NODEPARAMS                  22
#define IDS_NODEPICK                    23
#define IDD_PANEL                       101
#define IDD_DYNPARAM                    101
#define IDD_SIMPLE                      101
#define IDD_PANEL2                      103
#define IDD_DYNPARAM1                   104
#define IDD_PANEL3                      105
#define IDD_DIALOG1                     107
#define IDC_CLOSEBUTTON                 1000
#define IDC_DOSTUFF                     1000
#define IDC_APPLY                       1001
#define IDC_ADD                         1001
#define IDC_APPLY2                      1002
#define IDC_EDITSPIN                    1003
#define IDC_CHECK                       1004
#define IDC_STRING                      1006
#define IDC_REMOVE                      1007
#define IDC_APPLYFUNCTIONOBJ            1008
#define IDC_INSERT                      1008
#define IDC_APPLYMAT                    1010
#define IDC_MODELESS                    1012
#define IDC_APPLY_ML                    1014
#define IDC_REMOVE_MAT                  1016
#define IDC_CALIST                      1017
#define IDC_COLORS                      1019
#define IDC_NODEPICK                    1021
#define IDD_CUSTATTRIB                  1062
#define IDD_SWATCH                      1063
#define IDD_NODE                        1064
#define IDC_CA_COLOR                    1256
#define IDC_SUBMAP                      1256
#define IDC_COLOR                       1456
#define IDC_EDIT                        1490
#define IDC_SPIN                        1496

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        108
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1022
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
