/*	listpro.h - List class protocol, sample MAXScript SDK code for adding a new Value class
 *
 *  John Wainwright, 1998
 */
 
def_local_generic(car,		"car");
def_local_generic(cdr,		"cdr");
use_generic		 (plus,		"+");
use_generic		 (append,	"append");
use_generic		 (isEmpty,	"isEmpty");
