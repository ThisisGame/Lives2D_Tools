/*	settpro.h - Set class protocol, sample MAXScript SDK code for adding a new Value class
 *
 *  John Wainwright, 1998
 */
 
def_local_generic(isMember,		"isMember");
def_local_generic(intersection,	"intersection");
def_local_generic(union,		"union");
