/*	ClassCfg.h - local class & generic configuration file for MAXScript SDK plugins
 *
 *  John Wainwright, 1998
 */
 
// local root Value class for this plug-in

#define MS_LOCAL_ROOT_CLASS		ListValue

// local Generic function class
#define MS_LOCAL_GENERIC_CLASS	ListGeneric
