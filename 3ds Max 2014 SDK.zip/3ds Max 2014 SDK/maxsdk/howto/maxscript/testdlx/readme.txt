Readme for Testdlx workspace

This is sample source for creating plugins for MaxScript. It shows how to add a new type of custom control "FooControl" to MaxScript.

For more information on how to exposing functions to MaxScript, refer to MAXScript SDK topic of the MAX SDK help.

