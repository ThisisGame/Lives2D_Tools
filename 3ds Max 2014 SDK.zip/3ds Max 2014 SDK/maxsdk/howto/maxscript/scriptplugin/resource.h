//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ScP_Read.rc
//
#define IDS_CLASSNAME                   1
#define IDS_PARAMETERS                  2
#define IDS_LIBDESC                     4
#define IDS_CATEGORY                    5
#define IDD_SKELUTIL                    102
#define IDD_SCPLUTIL                    102
#define IDC_BTN1                        1000
#define IDC_CLOSE                       1001
#define IDC_GM1                         1003
#define IDC_GM2                         1004
#define IDC_DIFFUSE                     1702

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
